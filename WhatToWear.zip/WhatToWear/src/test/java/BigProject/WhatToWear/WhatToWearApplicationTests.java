package BigProject.WhatToWear;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhatToWearApplicationTests {

	@Test
	void contextLoads() {
	}

}
